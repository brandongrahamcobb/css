# bot/__init__.py

# This file can be left empty if no initialization is needed
